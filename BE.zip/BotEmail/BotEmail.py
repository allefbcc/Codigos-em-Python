import pyautogui
import time
import pyperclip

pyautogui.press('win')
pyautogui.write('opera')
time.sleep(1)
pyautogui.press('enter')

time.sleep(4)

pyautogui.hotkey('ctrl', 'shift', 'n')

time.sleep(2)

link = 'gmail.com'
pyperclip.copy(link)
pyautogui.hotkey('ctrl', 'v')

time.sleep(2)

pyautogui.press('enter')
time.sleep(12)
pyautogui.click(x=551, y=567)

time.sleep(8)
pyautogui.write('Jose')
pyautogui.press('tab')
pyautogui.write('Koff')
pyautogui.press('tab')
pyautogui.write('josekofgloss')
pyautogui.press('tab')
pyautogui.write('glossbrabo')
pyautogui.press('tab')
pyautogui.write('glossbrabo')
pyautogui.press('tab')
pyautogui.press('tab')
pyautogui.press('enter')





